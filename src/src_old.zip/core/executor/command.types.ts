export interface ICommandExec {
	command: string;
	args: string[];
}